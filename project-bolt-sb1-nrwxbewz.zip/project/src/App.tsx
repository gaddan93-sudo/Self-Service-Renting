import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { HomePage } from './pages/HomePage';
import { ProductPage } from './components/ProductPage';
import { HowItWorksPage } from './pages/HowItWorksPage';

function App() {
  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/produkt/:id" element={<ProductPage />} />
        <Route path="/hur-det-fungerar" element={<HowItWorksPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
