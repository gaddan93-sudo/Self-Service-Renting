export type ProductCategory = 'Kajak' | 'Båt' | 'Bastu';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  location: string;
  description: string;
  address: string;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export const products: Product[] = [
  {
    id: '1',
    name: 'Kajaker vid Leksands Sommarland',
    category: 'Kajak',
    location: 'Leksands Sommarland',
    description: 'Hyr kajak nära vattnet vid Leksands Sommarland.',
    address: 'Siljansvägen 75, 793 90 Leksand',
    coordinates: { lat: 60.7581484, lng: 14.9698915 }
  },
  {
    id: '2',
    name: 'Kajaker vid Siljansnäs Camping',
    category: 'Kajak',
    location: 'Siljansnäs Camping',
    description: 'Smidig kajakuthyrning vid Siljansnäs Camping.',
    address: 'Fjärdgattu 17, 793 60 Siljansnäs',
    coordinates: { lat: 60.7669805, lng: 14.8789486 }
  },
  {
    id: '3',
    name: 'Roddbåt vid Gassarvets badstrand',
    category: 'Båt',
    location: 'Gassarvets badstrand',
    description: 'Hyr en enkel roddbåt vid Gassarvets badstrand.',
    address: 'Mellanåkersvägen 20, 793 97 Siljansnäs',
    coordinates: { lat: 60.7685014, lng: 14.9136399 }
  },
  {
    id: '4',
    name: 'Bastu vid Gassarvets badstrand',
    category: 'Bastu',
    location: 'Gassarvets badstrand',
    description: 'Hyr en bastu nära badplatsen vid Gassarvets badstrand.',
    address: 'Mellanåkersvägen 20, 793 97 Siljansnäs',
    coordinates: { lat: 60.7684014, lng: 14.9135399 }
  },
  {
    id: '5',
    name: 'Bastu vid Siljansnäs Stugby',
    category: 'Bastu',
    location: 'Siljansnäs Stugby',
    description: 'Hyr bastu i närheten av Siljansnäs Stugby.',
    address: 'Buffils Annas väg 20, 793 60 Siljansnäs',
    coordinates: { lat: 60.7872892, lng: 14.8615306 }
  }
];

export const locations = [...new Set(products.map(p => p.location))];

export const categories: ProductCategory[] = ['Kajak', 'Båt', 'Bastu'];
