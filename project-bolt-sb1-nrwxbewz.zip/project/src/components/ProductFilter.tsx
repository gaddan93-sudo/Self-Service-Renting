import { Filter, MapPin, Loader2, Search } from 'lucide-react';
import { ProductCategory, locations } from '../data/products';

interface ProductFilterProps {
  selectedCategory: ProductCategory | 'Alla';
  selectedLocation: string;
  searchQuery: string;
  onCategoryChange: (category: ProductCategory | 'Alla') => void;
  onLocationChange: (location: string) => void;
  onSearchChange: (query: string) => void;
  onNearMe: () => void;
  isLoadingLocation: boolean;
  isNearMeActive: boolean;
}

export function ProductFilter({
  selectedCategory,
  selectedLocation,
  searchQuery,
  onCategoryChange,
  onLocationChange,
  onSearchChange,
  onNearMe,
  isLoadingLocation,
  isNearMeActive
}: ProductFilterProps) {
  return (
    <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between gap-4 mb-3">
          <div className="flex items-center gap-2">
            <Filter className="w-5 h-5 text-gray-500" />
            <span className="text-sm font-medium text-gray-700">Filtrera</span>
          </div>

          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Sök adress..."
              className="w-full pl-9 pr-4 py-2 text-sm border border-gray-300 rounded-lg bg-white text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => onCategoryChange('Alla')}
              className={`px-3 py-1.5 text-sm font-medium rounded-full border transition-all duration-200 ${
                selectedCategory === 'Alla'
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400 hover:bg-gray-50'
              }`}
            >
              Alla
            </button>
            {(['Kajak', 'Båt', 'Bastu'] as ProductCategory[]).map((category) => (
              <button
                key={category}
                onClick={() => onCategoryChange(category)}
                className={`px-3 py-1.5 text-sm font-medium rounded-full border transition-all duration-200 ${
                  selectedCategory === category
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400 hover:bg-gray-50'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="flex gap-2 sm:ml-auto">
            <select
              value={selectedLocation}
              onChange={(e) => onLocationChange(e.target.value)}
              className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:border-transparent"
            >
              <option value="">Alla områden</option>
              {locations.map((location) => (
                <option key={location} value={location}>
                  {location}
                </option>
              ))}
            </select>

            <button
              onClick={onNearMe}
              disabled={isLoadingLocation}
              className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg border transition-all duration-200 ${
                isNearMeActive
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-gray-700 border-gray-300 hover:border-gray-400 hover:bg-gray-50'
              } ${isLoadingLocation ? 'opacity-60 cursor-wait' : ''}`}
            >
              {isLoadingLocation ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <MapPin className="w-4 h-4" />
              )}
              <span className="hidden sm:inline">Visa nära mig</span>
              <span className="sm:hidden">Nära mig</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
