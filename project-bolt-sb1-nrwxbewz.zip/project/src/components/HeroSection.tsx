import { MapPin, CreditCard, Key } from 'lucide-react';

export function HeroSection() {
  return (
    <section className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white py-12 sm:py-16 lg:py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold leading-tight mb-6">
            Välj vad du vill hyra direkt från kartan, betala och få låskoden. Så enkelt är det.
          </h1>

          <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-8 mt-8">
            <div className="flex items-center gap-2 text-slate-300">
              <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center">
                <MapPin className="w-5 h-5 text-sky-400" />
              </div>
              <span className="text-sm sm:text-base font-medium">Hitta på karta</span>
            </div>

            <div className="flex items-center gap-2 text-slate-300">
              <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-emerald-400" />
              </div>
              <span className="text-sm sm:text-base font-medium">Betala tryggt</span>
            </div>

            <div className="flex items-center gap-2 text-slate-300">
              <div className="w-10 h-10 bg-slate-700 rounded-full flex items-center justify-center">
                <Key className="w-5 h-5 text-amber-400" />
              </div>
              <span className="text-sm sm:text-base font-medium">Få koden direkt</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
