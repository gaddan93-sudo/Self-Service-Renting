import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Link } from 'react-router-dom';
import { MapPin, X, Navigation } from 'lucide-react';
import { Product, ProductCategory } from '../data/products';

delete (L.Icon.Default.prototype as unknown as { _getIconUrl?: () => string })._get_iconUrl;

const categoryIcons: Record<ProductCategory, L.DivIcon> = {
  Kajak: L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="display: flex; flex-direction: column; align-items: center;">
        <div style="background: linear-gradient(135deg, #3b82f6, #1d4ed8); width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(59, 130, 246, 0.5); border: 2px solid white;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M2 12s3-3 6-3 6 3 6 3"/>
            <path d="M18 12c0 0-1.5-2-4-2s-4 2-4 2"/>
            <path d="M22 12h-4"/>
          </svg>
        </div>
        <div style="background: #3b82f6; color: white; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 4px; margin-top: 4px; white-space: nowrap; box-shadow: 0 1px 4px rgba(0,0,0,0.2);">
          Kajak
        </div>
      </div>
    `,
    iconSize: [36, 56],
    iconAnchor: [18, 56],
    popupAnchor: [0, -56],
  }),
  Båt: L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="display: flex; flex-direction: column; align-items: center;">
        <div style="background: linear-gradient(135deg, #14b8a6, #0d9488); width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(20, 184, 166, 0.5); border: 2px solid white;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.9 0 2.5 1 2.5 2s.6 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>
            <path d="M12 3v10"/>
            <path d="M19 13l-7-4-7 4"/>
          </svg>
        </div>
        <div style="background: #14b8a6; color: white; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 4px; margin-top: 4px; white-space: nowrap; box-shadow: 0 1px 4px rgba(0,0,0,0.2);">
          Roddbåt
        </div>
      </div>
    `,
    iconSize: [36, 56],
    iconAnchor: [18, 56],
    popupAnchor: [0, -56],
  }),
  Bastu: L.divIcon({
    className: 'custom-marker',
    html: `
      <div style="display: flex; flex-direction: column; align-items: center;">
        <div style="background: linear-gradient(135deg, #f59e0b, #d97706); width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(245, 158, 11, 0.5); border: 2px solid white;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2c-1 2-4 4-4 7 0 3 2.5 5 4 6"/>
            <path d="M12 2c1 2 4 4 4 7 0 3-2.5 5-4 6"/>
            <path d="M12 22c-2 0-5-3-5-7 0-2 2-3 5-3s5 1 5 3c0 4-3 7-5 7"/>
          </svg>
        </div>
        <div style="background: #f59e0b; color: white; font-size: 11px; font-weight: 600; padding: 2px 8px; border-radius: 4px; margin-top: 4px; white-space: nowrap; box-shadow: 0 1px 4px rgba(0,0,0,0.2);">
          Bastu
        </div>
      </div>
    `,
    iconSize: [36, 56],
    iconAnchor: [18, 56],
    popupAnchor: [0, -56],
  }),
};

const myLocationIcon = new L.DivIcon({
  html: `<div style="background-color: #0ea5e9; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);"></div>`,
  className: 'my-location-marker',
  iconSize: [16, 16],
  iconAnchor: [8, 8],
});

interface MapSectionProps {
  products: (Product | (Product & { distance?: number }))[];
  userLocation?: { lat: number; lng: number } | null;
  distance?: number;
}

function MapBounds({ products, userLocation }: { products: (Product | (Product & { distance?: number }))[]; userLocation?: { lat: number; lng: number } | null }) {
  const map = useMap();

  useEffect(() => {
    const points: [number, number][] = [];

    if (userLocation) {
      points.push([userLocation.lat, userLocation.lng]);
    }

    products.forEach((p) => {
      points.push([p.coordinates.lat, p.coordinates.lng]);
    });

    if (points.length > 0) {
      const bounds = L.latLngBounds(points);
      map.fitBounds(bounds, { padding: [60, 60] });
    }
  }, [map, products, userLocation]);

  return null;
}

const categoryColors: Record<ProductCategory, string> = {
  'Kajak': 'bg-blue-100 text-blue-800 border-blue-200',
  'Båt': 'bg-teal-100 text-teal-800 border-teal-200',
  'Bastu': 'bg-amber-100 text-amber-800 border-amber-200'
};

function ProductPopup({ product, onClose }: { product: Product; onClose: () => void }) {
  return (
    <div className="min-w-[200px]">
      <div className="flex items-start justify-between gap-2 mb-2">
        <h3 className="text-base font-semibold text-gray-900 leading-tight pr-4">
          {product.name}
        </h3>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-600 transition-colors p-0.5"
          aria-label="Stäng"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
        <MapPin className="w-3.5 h-3.5" />
        <span>{product.location}</span>
      </div>

      <div className="mb-3">
        <span className={`inline-block px-2 py-0.5 text-xs font-medium rounded-full border ${categoryColors[product.category]}`}>
          {product.category}
        </span>
      </div>

      <Link
        to={`/produkt/${product.id}`}
        className="inline-flex items-center justify-center w-full px-3 py-2 text-sm font-medium text-white bg-slate-900 rounded hover:bg-slate-800 transition-colors"
      >
        Visa produkt
      </Link>
    </div>
  );
}

export function MapSection({ products, userLocation, distance = 50 }: MapSectionProps) {
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);

  const defaultCenter: [number, number] = [60.73, 14.73];
  const defaultZoom = 12;

  return (
    <div className="relative bg-slate-100">
      <MapContainer
        center={userLocation ? [userLocation.lat, userLocation.lng] : defaultCenter}
        zoom={defaultZoom}
        className="h-[50vh] sm:h-[60vh] min-h-[400px] w-full z-0"
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapBounds products={products} userLocation={userLocation} />

        {userLocation && (
          <>
            <Circle
              center={[userLocation.lat, userLocation.lng]}
              radius={distance * 1000}
              pathOptions={{
                fillColor: '#0ea5e9',
                fillOpacity: 0.1,
                color: '#0ea5e9',
                weight: 2,
                opacity: 0.4
              }}
            />
            <Marker
              position={[userLocation.lat, userLocation.lng]}
              icon={myLocationIcon}
            >
              <Popup closeButton={false}>
                <div className="flex items-center gap-2 text-sm font-medium text-gray-900">
                  <Navigation className="w-4 h-4 text-sky-500" />
                  Din plats
                </div>
              </Popup>
            </Marker>
          </>
        )}

        {products.map((product) => (
          <Marker
            key={product.id}
            position={[product.coordinates.lat, product.coordinates.lng]}
            icon={categoryIcons[product.category]}
            eventHandlers={{
              click: () => setActiveProduct(product)
            }}
          >
            <Popup closeButton={false} className="custom-popup">
              <ProductPopup
                product={product}
                onClose={() => setActiveProduct(null)}
              />
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      <div className="absolute top-4 left-4 right-4 sm:left-6 sm:right-auto z-[1000]">
        <div className="bg-white rounded-lg shadow-lg px-4 py-3 sm:px-5 sm:py-3.5 max-w-xs">
          <h2 className="text-base sm:text-lg font-semibold text-gray-900">
            {userLocation ? 'Nära dig' : 'Leksand, Dalarna'}
          </h2>
          <p className="text-xs sm:text-sm text-gray-500 mt-0.5">
            {products.length} produkter {userLocation ? 'visas' : 'i området'}
          </p>
        </div>
      </div>
    </div>
  );
}
