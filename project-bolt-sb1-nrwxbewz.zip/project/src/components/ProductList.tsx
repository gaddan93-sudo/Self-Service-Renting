import { ProductCard } from './ProductCard';
import { Product } from '../data/products';

interface ProductListProps {
  products: (Product & { distance?: number })[];
}

export function ProductList({ products: productList }: ProductListProps) {
  if (productList.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">Inga produkter hittades för dina filter.</p>
          <p className="text-gray-400 text-sm mt-2">Prova att ändra dina filteralternativ.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg sm:text-xl font-semibold text-gray-900">
          Produkter ({productList.length})
        </h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {(productList as (Product & { distance?: number })[]).map((product) => (
          <ProductCard key={product.id} product={product} distance={product.distance} />
        ))}
      </div>
    </div>
  );
}
