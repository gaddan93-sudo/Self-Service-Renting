import { MapPin, ArrowLeft, Package, Home } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import { useState } from 'react';
import { products } from '../data/products';
import { BookingForm } from './BookingForm';

const categoryColors = {
  'Kajak': 'bg-blue-100 text-blue-800',
  'Båt': 'bg-teal-100 text-teal-800',
  'Bastu': 'bg-amber-100 text-amber-800'
};

export function ProductPage() {
  const { id } = useParams<{ id: string }>();
  const product = products.find((p) => p.id === id);
  const [showBookingForm, setShowBookingForm] = useState(false);

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Produkten hittades inte</h1>
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-slate-900 hover:text-slate-700 font-medium"
          >
            <ArrowLeft className="w-4 h-4" />
            Tillbaka till startsidan
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-slate-900 hover:text-slate-700 font-medium transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Tillbaka
          </Link>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="aspect-video sm:aspect-[21/9] bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
            <div className="text-center">
              <Package className="w-16 h-16 sm:w-20 sm:h-20 text-slate-400 mx-auto mb-3" />
              <p className="text-slate-500 text-sm">Produktbild</p>
            </div>
          </div>

          <div className="p-5 sm:p-6 lg:p-8">
            <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-900">
                {product.name}
              </h1>
              <span className={`px-3 py-1.5 text-sm font-medium rounded-full ${categoryColors[product.category]}`}>
                {product.category}
              </span>
            </div>

            <div className="flex items-center gap-2 text-gray-600 mb-2">
              <MapPin className="w-5 h-5 text-gray-500" />
              <span className="text-base sm:text-lg">{product.location}</span>
            </div>

            <div className="flex items-center gap-2 text-gray-500 mb-5">
              <Home className="w-5 h-5 text-gray-400" />
              <span className="text-sm">{product.address}</span>
            </div>

            <p className="text-gray-600 text-base sm:text-lg mb-8">
              {product.description}
            </p>

            <button
              onClick={() => setShowBookingForm(true)}
              className="w-full sm:w-auto px-6 py-3.5 text-base font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors duration-200"
            >
              Boka
            </button>
          </div>
        </div>
      </div>

      {showBookingForm && (
        <BookingForm
          product={product}
          onClose={() => setShowBookingForm(false)}
        />
      )}
    </div>
  );
}
