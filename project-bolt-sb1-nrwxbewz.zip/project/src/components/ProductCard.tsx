import { MapPin, Navigation } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
  distance?: number;
}

const categoryColors = {
  'Kajak': 'bg-blue-100 text-blue-800 border-blue-200',
  'Båt': 'bg-teal-100 text-teal-800 border-teal-200',
  'Bastu': 'bg-amber-100 text-amber-800 border-amber-200'
};

export function ProductCard({ product, distance }: ProductCardProps) {
  return (
    <div className="bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden">
      <div className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <h3 className="text-base sm:text-lg font-semibold text-gray-900 leading-tight">
            {product.name}
          </h3>
          <span className={`px-2.5 py-1 text-xs font-medium rounded-full border whitespace-nowrap ${categoryColors[product.category]}`}>
            {product.category}
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-sm text-gray-600 mb-2">
          <MapPin className="w-4 h-4 flex-shrink-0" />
          <span>{product.location}</span>
        </div>

        {distance !== undefined && (
          <div className="flex items-center gap-1.5 text-sm text-sky-600 mb-1">
            <Navigation className="w-4 h-4 flex-shrink-0" />
            <span>{distance.toFixed(1)} km från dig</span>
          </div>
        )}

        <p className="text-sm text-gray-500 mb-4 line-clamp-2">
          {product.description}
        </p>

        <Link
          to={`/produkt/${product.id}`}
          className="inline-flex items-center justify-center w-full px-4 py-2.5 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors duration-200"
        >
          Visa produkt
        </Link>
      </div>
    </div>
  );
}
