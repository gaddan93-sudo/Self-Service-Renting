import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Info } from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-slate-800 to-slate-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">ER</span>
            </div>
            <span className="text-xl font-bold text-slate-900">EasyRenting</span>
          </Link>

          <nav className="hidden sm:flex items-center gap-6">
            <Link
              to="/hur-det-fungerar"
              className={`flex items-center gap-2 text-sm font-medium transition-colors ${
                location.pathname === '/hur-det-fungerar'
                  ? 'text-slate-900'
                  : 'text-gray-600 hover:text-slate-900'
              }`}
            >
              <Info className="w-4 h-4" />
              Hur det fungerar
            </Link>
          </nav>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="sm:hidden p-2 text-gray-600 hover:text-slate-900"
            aria-label="Meny"
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="sm:hidden py-3 border-t border-gray-100">
            <Link
              to="/hur-det-fungerar"
              onClick={() => setIsMenuOpen(false)}
              className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg ${
                location.pathname === '/hur-det-fungerar'
                  ? 'bg-slate-100 text-slate-900'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Info className="w-4 h-4" />
              Hur det fungerar
            </Link>
          </div>
        )}
      </div>
    </header>
  );
}
