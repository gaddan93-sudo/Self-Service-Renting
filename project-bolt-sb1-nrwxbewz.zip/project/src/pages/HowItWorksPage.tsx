import { MapPin, CreditCard, Key, Clock, Shield, Smartphone, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const steps = [
  {
    icon: MapPin,
    title: 'Hitta på kartan',
    description: 'Se alla tillgängliga produkter direkt på kartan. Välj det som passar dig bäst baserat på läge och typ.'
  },
  {
    icon: Clock,
    title: 'Välj tid',
    description: 'Bestäm när du vill hyra och hur länge. Systemet visar direkt vad som är tillgängligt.'
  },
  {
    icon: CreditCard,
    title: 'Betala tryggt',
    description: 'Betala säkert med kort eller Swish. All betalning sker krypterat via våra betalningspartners.'
  },
  {
    icon: Key,
    title: 'Få koden',
    description: 'Direkt efter betalning får du en bokningsbekräftelse med låskod och instruktioner till din e-post.'
  }
];

const benefits = [
  {
    icon: Smartphone,
    title: 'Dygnet runt',
    description: 'Boka när det passar dig - dygnet runt, alla dagar i veckan.'
  },
  {
    icon: Shield,
    title: 'Trygghet',
    description: 'Alla betalningar är säkrade och du får alltid bekräftelse via e-post.'
  },
  {
    icon: Clock,
    title: 'Inga köer',
    description: 'Slipp vänta. Boka, betala och få tillgång direkt.'
  }
];

export function HowItWorksPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-slate-900 hover:text-slate-700 font-medium transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Tillbaka
          </Link>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="text-center mb-12 sm:mb-16">
          <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Hur det fungerar
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Hyra ska vara enkelt. Med EasyRenting bokar och betalar du direkt, och får omedelbar tillgång till produkten.
          </p>
        </div>

        <div className="mb-16 sm:mb-20">
          <h2 className="text-xl sm:text-2xl font-semibold text-gray-900 mb-8 text-center">
            Steg för steg
          </h2>
          <div className="grid gap-6 sm:gap-8">
            {steps.map((step, index) => (
              <div
                key={index}
                className="bg-white rounded-xl border border-gray-200 p-6 sm:p-8 flex flex-col sm:flex-row gap-4 sm:gap-6"
              >
                <div className="flex items-start gap-4 sm:block">
                  <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center flex-shrink-0 sm:mb-4">
                    <step.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="sm:hidden">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-slate-600">Steg {index + 1}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">{step.title}</h3>
                  </div>
                </div>
                <div>
                  <span className="hidden sm:block text-sm font-medium text-slate-600 mb-1">
                    Steg {index + 1}
                  </span>
                  <h3 className="hidden sm:block text-xl font-semibold text-gray-900 mb-2">
                    {step.title}
                  </h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-2xl p-8 sm:p-12 text-white">
          <h2 className="text-xl sm:text-2xl font-semibold mb-8 text-center">
            Fördelar med EasyRenting
          </h2>
          <div className="grid sm:grid-cols-3 gap-6 sm:gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="w-14 h-14 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="w-7 h-7 text-slate-300" />
                </div>
                <h3 className="font-semibold mb-2">{benefit.title}</h3>
                <p className="text-slate-400 text-sm">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 sm:mt-16 text-center">
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-8 py-4 bg-slate-900 text-white font-medium rounded-lg hover:bg-slate-800 transition-colors"
          >
            Hitta produkter nu
          </Link>
        </div>
      </div>
    </div>
  );
}
