import { useState, useMemo, useCallback } from 'react';
import { MapSection } from '../components/MapSection';
import { ProductList } from '../components/ProductList';
import { ProductFilter } from '../components/ProductFilter';
import { HeroSection } from '../components/HeroSection';
import { products, ProductCategory, Product } from '../data/products';

interface ProductWithDistance extends Product {
  distance: number;
}

function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'Alla'>('Alla');
  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [isNearMeActive, setIsNearMeActive] = useState(false);
  const [distance, setDistance] = useState<number>(20);
  const [locationError, setLocationError] = useState<string | null>(null);

  const handleNearMe = useCallback(() => {
    if (isNearMeActive) {
      setIsNearMeActive(false);
      setUserLocation(null);
      setDistance(20);
      setLocationError(null);
      return;
    }

    if (!navigator.geolocation) {
      setLocationError('Din webbläsare stöder inte geolokalisering');
      return;
    }

    setIsLoadingLocation(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
        setIsNearMeActive(true);
        setIsLoadingLocation(false);
        setDistance(50);
      },
      (error) => {
        setIsLoadingLocation(false);
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setLocationError('Du måste tillåta åtkomst till din plats');
            break;
          case error.POSITION_UNAVAILABLE:
            setLocationError('Kunde inte bestämma din plats');
            break;
          case error.TIMEOUT:
            setLocationError('Det tog för lång tid att hitta din plats');
            break;
          default:
            setLocationError('Ett fel uppstod vid hämtning av din plats');
        }
      },
      {
        enableHighAccuracy: false,
        timeout: 10000,
        maximumAge: 300000
      }
    );
  }, [isNearMeActive]);

  const filteredProducts = useMemo(() => {
    let result: (Product | ProductWithDistance)[] = products;

    if (selectedCategory !== 'Alla') {
      result = result.filter((p) => p.category === selectedCategory);
    }

    if (selectedLocation) {
      result = result.filter((p) => p.location === selectedLocation);
    }

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      result = result.filter((p) =>
        p.address.toLowerCase().includes(query) ||
        p.location.toLowerCase().includes(query) ||
        p.name.toLowerCase().includes(query)
      );
    }

    if (userLocation && isNearMeActive) {
      result = result
        .map((product): ProductWithDistance => ({
          ...product,
          distance: calculateDistance(
            userLocation.lat,
            userLocation.lng,
            product.coordinates.lat,
            product.coordinates.lng
          )
        }))
        .filter((product) => product.distance <= distance)
        .sort((a, b) => a.distance - b.distance);
    }

    return result;
  }, [selectedCategory, selectedLocation, searchQuery, userLocation, isNearMeActive, distance]);

  return (
    <div className="min-h-screen bg-gray-50">
      <HeroSection />
      <MapSection products={filteredProducts} userLocation={userLocation} distance={distance} />
      <ProductFilter
        selectedCategory={selectedCategory}
        selectedLocation={selectedLocation}
        searchQuery={searchQuery}
        onCategoryChange={setSelectedCategory}
        onLocationChange={setSelectedLocation}
        onSearchChange={setSearchQuery}
        onNearMe={handleNearMe}
        isLoadingLocation={isLoadingLocation}
        isNearMeActive={isNearMeActive}
      />
      {locationError && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
            {locationError}
          </div>
        </div>
      )}
      {isNearMeActive && userLocation && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex items-center justify-between bg-slate-50 border border-slate-200 px-4 py-3 rounded-lg">
            <span className="text-sm text-slate-700">
              Visar produkter inom <strong className="font-semibold">{distance} km</strong> från din plats
            </span>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min="5"
                max="100"
                value={distance}
                onChange={(e) => setDistance(Number(e.target.value))}
                className="w-24 sm:w-32 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-slate-900"
              />
              <span className="text-sm text-slate-600 w-10">{distance} km</span>
            </div>
          </div>
        </div>
      )}
      <ProductList products={filteredProducts} />
    </div>
  );
}
